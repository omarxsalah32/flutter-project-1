import 'package:new_capital_summer_db/db/db_constants.dart';
import 'package:new_capital_summer_db/enums/note_type.dart';

class Note {
  final int? id;
  final String title;
  final String content;
  final String createdAt;
  final NoteType type;

  Note({
    this.id,
    required this.title,
    required this.content,
    required this.createdAt,
    required this.type,
  });

  Map<String, dynamic> toMap() => {
    DbConstants.noteId: id,
    DbConstants.noteTitle: title,
    DbConstants.noteContent: content,
    DbConstants.createdAt: createdAt,
    DbConstants.noteType: type.name,
  };

  factory Note.fromMap(Map<String, dynamic> map) {
    return Note(
      id: map[DbConstants.noteId],
      title: map[DbConstants.noteTitle],
      content: map[DbConstants.noteContent],
      createdAt: map[DbConstants.createdAt],
      type: NoteType.values.firstWhere(
        (e) => e.name == map[DbConstants.noteType],
      ),
    );
  }

  Note copyWith({
    int? id,
    String? title,
    String? content,
    String? createdAt,
    NoteType? type,
  }) {
    return Note(
      id: id ?? this.id,
      title: title ?? this.title,
      content: content ?? this.content,
      createdAt: createdAt ?? this.createdAt,
      type: type ?? this.type,
    );
  }
}
