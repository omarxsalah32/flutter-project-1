import 'package:flutter/material.dart';
import 'package:new_capital_summer_db/core/resources/app_colors.dart';
import 'package:new_capital_summer_db/presentation/screens/note_home_screen.dart';
import 'package:new_capital_summer_db/presentation/ui_model/grid_item.dart';
import 'package:new_capital_summer_db/presentation/ui_model/nav_item.dart';

import '../resources/app_icons.dart';

class UiConstants {
  UiConstants._();

  static List<NavItem> navItems = [
    NavItem('Home', Icons.home, MyHomePage()),
    NavItem('Finished', Icons.task, MyHomePage()),
    NavItem('', Icons.add, MyHomePage()),
    NavItem('Search', Icons.search, MyHomePage()),
    NavItem('Settings', Icons.settings, MyHomePage()),
  ];

  static List<GridItem> gridItems = [
    GridItem(
      AppIcons.icon1,
      'Interesting Idea',
      'Use free text area, feel free to write it all',
      AppColors.purple,
    ),
    GridItem(
      AppIcons.icon1,
      'Goals',
      'Use free text area, feel free to write it all',
      AppColors.yellow,
    ),
    GridItem(
      AppIcons.icon1,
      'Guidance',
      'Use free text area, feel free to write it all',
      AppColors.shrimp,
    ),
    GridItem(
      AppIcons.icon1,
      'Buy Something',
      'Use free text area, feel free to write it all',
      AppColors.green,
    ),
    GridItem(
      AppIcons.icon1,
      'Routine Tasks',
      'Use free text area, feel free to write it all',
      AppColors.lime,
    ),
  ];
}
