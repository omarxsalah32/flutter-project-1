import 'package:flutter/material.dart';

class AppColors {
  AppColors._();

  static const Color primary = Color(0xFFFFFFFF);
  static const Color whiteE5 = Color(0xFFE5E5E5);
  static const Color purple = Color(0xFF6A3EA1);
  static const Color yellow = Color(0xFFF8C715);
  static const Color green = Color(0xFF60D889);
  static const Color lime = Color(0xFFDEDC52);
  static const Color shrimp = Color(0xFFCE3A54);
  static const Color darkGrey = Color(0xFF827D89);
  static const Color lightYellow = Color(0xFFF7F6D4);
  static const Color black = Color(0xFF000000);
  static const Color grey = Color(0xFFC8C5CB);
}
