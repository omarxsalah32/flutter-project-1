import 'package:flutter/material.dart';

import 'app_colors.dart';

class AppButtonStyle {
  AppButtonStyle._();
  static ButtonStyle primaryButton = IconButton.styleFrom(
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
    backgroundColor: AppColors.purple,
  );
}
