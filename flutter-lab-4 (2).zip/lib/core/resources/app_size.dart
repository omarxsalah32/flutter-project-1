import 'package:flutter/cupertino.dart';

class AppSize {
  AppSize._();

  static const double smPadding = 8;
  static const double mdPadding = 16;

  //radius
  static final BorderRadiusGeometry smRadius = BorderRadius.circular(8);

  //fonts
  static const double xsmFont = 10;
  static const double smFont = 12;
  static const double mdFont = 14;
  static const double lgFont = 16;
  static const double xlFont = 24;
  static const double xxlFont = 32;

  //spacing
  static const double xsmSpacing = 4;
  static const double mdSpacing = 20;

  //section Height
  static const double h224 = 224;
  static const double h1 = 1;
  static const double h16 = 16;
  static const double w16 = 16;
  static const double h32 = 32;
  static const double w100 = 100;

  //elevation
  static const double smElevation = 0.5;
}
