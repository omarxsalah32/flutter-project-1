class AppIcons {
  AppIcons._();

  static const String _path = 'assets/icons/';
  static const String icon1 = '${_path}icon1.svg';
  static const String background = '${_path}bg.svg';
}
