import 'package:flutter/material.dart';

import 'app_colors.dart';
import 'app_size.dart';

class AppTextStyles {
  AppTextStyles._();

  static const String appFontFamily = 'Inter';

  static const TextStyle black10Regular = TextStyle(
    color: AppColors.black,
    fontSize: AppSize.xsmFont,
    fontFamily: appFontFamily,
    fontWeight: FontWeight.normal,
  );

  static const TextStyle black16Medium = TextStyle(
    color: AppColors.black,
    fontSize: AppSize.mdFont,
    fontFamily: appFontFamily,
    fontWeight: FontWeight.w500,
  );

  static const TextStyle black16Regular = TextStyle(
    color: AppColors.black,
    fontSize: AppSize.mdFont,
    fontFamily: appFontFamily,
    fontWeight: FontWeight.normal,
  );

  static const TextStyle black24Bold = TextStyle(
    color: AppColors.black,
    fontSize: AppSize.xlFont,
    fontFamily: appFontFamily,
    fontWeight: FontWeight.bold,
  );

  static const TextStyle black14Bold = TextStyle(
    color: AppColors.black,
    fontSize: AppSize.mdFont,
    fontFamily: appFontFamily,
    fontWeight: FontWeight.bold,
  );

  static const TextStyle black32Bold = TextStyle(
    color: AppColors.black,
    fontSize: AppSize.xxlFont,
    fontFamily: appFontFamily,
    fontWeight: FontWeight.bold,
  );

  static const TextStyle purple12MediumUnderline = TextStyle(
    color: AppColors.purple,
    fontSize: AppSize.smFont,
    fontFamily: appFontFamily,
    fontWeight: FontWeight.w500,
    decoration: TextDecoration.underline,
  );
}
