import 'package:flutter/material.dart';
import 'package:new_capital_summer_db/db/db_helper.dart';

import 'my_app.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  DbHelper.helper.getInstance();
  runApp(const MyApp());
}
