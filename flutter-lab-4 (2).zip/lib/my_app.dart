import 'package:flutter/material.dart';
import 'package:new_capital_summer_db/core/resources/app_colors.dart';
import 'package:new_capital_summer_db/presentation/screens/main_screen.dart';
import 'package:new_capital_summer_db/presentation/screens/note_home_screen.dart';

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(scaffoldBackgroundColor: AppColors.whiteE5),
      home: MainScreen(),
    );
  }
}
