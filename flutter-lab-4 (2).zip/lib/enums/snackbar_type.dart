import 'package:flutter/material.dart';

enum SnackBarType {
  success,
  error,
  warning,
  info,
  loading;

  Color textColor() {
    switch (this) {
      case success:
      case error:
      case info:
        return Colors.white;
      case warning:
      case loading:
        return Colors.black;
    }
  }

  Color bgColor() {
    switch (this) {
      case success:
        return Colors.green;
      case error:
        return Colors.red;
      case warning:
        return Colors.orange;
      case loading:
        return Colors.yellow;
      case info:
        return Colors.blue;
    }
  }
}
