enum NoteType { interesting, goals, routines, buy, guidance }
