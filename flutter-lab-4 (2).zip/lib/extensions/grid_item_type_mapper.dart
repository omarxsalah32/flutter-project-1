import 'package:new_capital_summer_db/enums/note_type.dart';
import 'package:new_capital_summer_db/presentation/ui_model/grid_item.dart';

extension GridItemTypeMapper on GridItem {
  NoteType toType() {
    switch (this.title) {
      case 'Interesting Idea':
        return NoteType.interesting;
      case 'Goals':
        return NoteType.goals;
      case 'Guidance':
        return NoteType.guidance;
      case 'Buy Something':
        return NoteType.buy;
      case 'Routine Tasks':
        return NoteType.routines;
      default:
        throw ArgumentError('Unknown note type: ${this.title}');
    }
  }
}
