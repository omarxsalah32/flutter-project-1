import 'package:flutter/material.dart';

import '../enums/snackbar_type.dart';

extension ContextExtension on BuildContext {
  void navigateTo(Widget page) {
    Navigator.push(this, MaterialPageRoute(builder: (context) => page));
  }

  void showSnackBar(
    String message, {
    SnackBarType? type = SnackBarType.info,
    String? actionLabel,
    VoidCallback? action,
  }) {
    ScaffoldMessenger.of(this).showSnackBar(
      SnackBar(
        behavior: SnackBarBehavior.floating,
        action: SnackBarAction(
          label: actionLabel ?? '',
          onPressed: action ?? () {},
        ),
        margin: EdgeInsets.all(8.0),
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        content: Text(message, style: TextStyle(color: type?.textColor())),
        backgroundColor: type?.bgColor(),
      ),
    );
  }

  void hideSnackBar() {
    ScaffoldMessenger.of(this).hideCurrentSnackBar();
  }
}
