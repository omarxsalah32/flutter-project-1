import 'package:flutter/material.dart';
import 'package:new_capital_summer_db/db/db_constants.dart';
import 'package:new_capital_summer_db/db/db_helper.dart';
import 'package:sqflite/sqflite.dart';

import '../model/note.dart';

class Crud {
  Crud._();

  static final Crud instance = Crud._();
  static ValueNotifier<List<Note>> notesNotifier = ValueNotifier([]);

  static final List<Note> _flutLabMemoryNotes = [];
  static int _mockIdCounter = 1;

  // 1. insert note
  Future<int> addNote(Note note) async {
    try {
      Database db = await DbHelper.helper.getInstance();
      int row = await db.insert(
        DbConstants.tableName,
        note.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
      await viewAllNotes();
      return row;
    } catch (e) {
      Note newNote = note.copyWith(id: _mockIdCounter++);
      _flutLabMemoryNotes.add(newNote);
      await viewAllNotes();
      return newNote.id!;
    }
  }

  // 2. select all
  Future<void> viewAllNotes() async {
    try {
      Database db = await DbHelper.helper.getInstance();
      List<Map<String, Object?>> result = await db.query(DbConstants.tableName);
      List<Note> notes = result.map((e) => Note.fromMap(e)).toList();
      notesNotifier.value = notes;
    } catch (e) {
      notesNotifier.value = List.from(_flutLabMemoryNotes);
    }
  }

  // 3. update note
  Future<int> updateNote(Note note) async {
    try {
      Note newNote = note.copyWith(
        title: note.title,
        content: note.content,
        createdAt: note.createdAt,
      );
      Database db = await DbHelper.helper.getInstance();
      int row = await db.update(
        DbConstants.tableName,
        newNote.toMap(),
        where: '${DbConstants.noteId}=?',
        whereArgs: [note.id],
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
      await viewAllNotes();
      return row;
    } catch (e) {
      int index = _flutLabMemoryNotes.indexWhere((n) => n.id == note.id);
      if (index != -1) {
        _flutLabMemoryNotes[index] = note;
      }
      await viewAllNotes();
      return 1;
    }
  }

  // 4. delete note
  Future<int> deleteNote(int id) async {
    try {
      Database db = await DbHelper.helper.getInstance();
      int row = await db.delete(
        DbConstants.tableName,
        where: '${DbConstants.noteId}=?',
        whereArgs: [id],
      );
      await viewAllNotes();
      return row;
    } catch (e) {
      _flutLabMemoryNotes.removeWhere((n) => n.id == id);
      await viewAllNotes();
      return 1;
    }
  }

  // 5. select by type
  Future<void> viewNotesByType(String type) async {
    try {
      Database db = await DbHelper.helper.getInstance();
      List<Map<String, Object?>> result = await db.query(
        DbConstants.tableName,
        where: '${DbConstants.noteType}=?',
        whereArgs: [type],
      );
      List<Note> notes = result.map((e) => Note.fromMap(e)).toList();
      notesNotifier.value = notes;
    } catch (e) {
      notesNotifier.value =
          _flutLabMemoryNotes.where((n) => n.type.name == type).toList();
    }
  }
}
