class DbConstants {
  DbConstants._();

  static const String dbName = 'notes';
  static const int dbVersion = 3;

  ///------------------Tables & Cols------------------
  static const String tableName = 'note';
  static const String noteId = 'id';
  static const String noteTitle = 'note_title';
  static const String noteContent = 'note_content';
  static const String createdAt = 'created_at';
  static const String noteType = 'note_type';
}
