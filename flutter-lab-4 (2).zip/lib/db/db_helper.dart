import 'dart:async';

import 'package:flutter/material.dart';
import 'package:new_capital_summer_db/db/db_constants.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class DbHelper {
  DbHelper._();

  static final DbHelper helper = DbHelper._();

  //db path
  Future<String> _getDbPath() async {
    String path = await getDatabasesPath();
    return join(path, DbConstants.dbName);
  }

  Future<Database> getInstance() async {
    String path = await _getDbPath();
    return await openDatabase(
      path,
      onConfigure: _onConfigure,
      onCreate: _onCreate,
      onOpen: _onOpen,
      onUpgrade: _onUpgrade,
      onDowngrade: _onDowngrade,
      readOnly: false,
      singleInstance: true,
      version: DbConstants.dbVersion,
    );
  }

  FutureOr<void> _onConfigure(Database db) {
    debugPrint('onConfigure ${db.path}');
  }

  FutureOr<void> _onCreate(Database db, int version) {
    debugPrint('_onCreate ${db.path}, $version');
    String sql =
        'create table ${DbConstants.tableName} (${DbConstants.noteId} integer primary key autoincrement, ${DbConstants.noteTitle} text, ${DbConstants.noteContent} text, ${DbConstants.createdAt} text)';
    try {
      db.execute(sql);
    } catch (e) {
      debugPrint('Error creating table: $e');
    }
  }

  FutureOr<void> _onOpen(Database db) {
    debugPrint('_onOpen ${db.path}');
  }

  FutureOr<void> _onUpgrade(Database db, int oldVersion, int newVersion) {
    debugPrint('_onUpgrade ${db.path}, $oldVersion, $newVersion');
    String sql =
        'alter table ${DbConstants.tableName} add column ${DbConstants.noteType} text';
    try {
      db.execute(sql);
    } catch (e) {
      debugPrint('Error altering table: $e');
    }
  }

  FutureOr<void> _onDowngrade(Database db, int oldVersion, int newVersion) {
    debugPrint('_onDowngrade ${db.path}, $oldVersion, $newVersion');
  }
}
