class DateTimeManager{
  static String getCurrentDateTime(){
    return DateTime.now().toIso8601String();
  }
}