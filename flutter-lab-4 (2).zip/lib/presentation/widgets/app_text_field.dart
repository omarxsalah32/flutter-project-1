import 'package:flutter/material.dart';
import 'package:new_capital_summer_db/core/resources/app_text_styles.dart';

import '../../core/resources/app_colors.dart';

class AppTextField extends StatelessWidget {
  const AppTextField({
    super.key,
    required this.title,
    this.isTitle = false,
    required this.controller,
  });

  final String title;
  final bool? isTitle;
  final TextEditingController controller;

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      style: isTitle == true
          ? AppTextStyles.black32Bold
          : AppTextStyles.black16Regular,
      controller: controller,
      keyboardType: TextInputType.text,
      textInputAction:
          isTitle == true ? TextInputAction.next : TextInputAction.done,
      decoration: InputDecoration(
        border: InputBorder.none,
        hintText: title,
        hintStyle: isTitle == true
            ? AppTextStyles.black32Bold.copyWith(color: AppColors.grey)
            : AppTextStyles.black16Regular.copyWith(color: AppColors.grey),
      ),
    );
  }
}
