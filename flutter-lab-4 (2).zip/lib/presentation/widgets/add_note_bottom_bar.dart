import 'package:flutter/material.dart';
import 'package:new_capital_summer_db/core/resources/app_button_style.dart';
import 'package:new_capital_summer_db/core/resources/app_colors.dart';
import 'package:new_capital_summer_db/core/resources/app_size.dart';
import 'package:new_capital_summer_db/core/resources/app_text_styles.dart';

class AddNoteBottomBar extends StatelessWidget {
  const AddNoteBottomBar({super.key, required this.onTap});
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.zero,
      decoration: BoxDecoration(
        color: AppColors.primary,
        border: Border(top: BorderSide(color: AppColors.darkGrey)),
      ),
      height: kBottomNavigationBarHeight,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Padding(
              padding: EdgeInsets.only(left: AppSize.smPadding),
              child: Text(
                'Saved at',
                style: AppTextStyles.black10Regular.copyWith(
                  fontSize: AppSize.smFont,
                ),
              ),
            ),
          ),
          Expanded(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                IconButton(
                  onPressed: () {},
                  icon: Icon(Icons.color_lens_outlined),
                ),
                IconButton(onPressed: onTap, icon: Icon(Icons.save)),
                IconButton(
                  style: AppButtonStyle.primaryButton,
                  onPressed: () {},
                  icon: Icon(Icons.more_horiz, color: AppColors.primary),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
