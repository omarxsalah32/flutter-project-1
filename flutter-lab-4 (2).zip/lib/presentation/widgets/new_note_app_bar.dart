import 'package:flutter/material.dart';
import 'package:new_capital_summer_db/core/resources/app_colors.dart';
import 'package:new_capital_summer_db/core/resources/app_size.dart';
import 'package:new_capital_summer_db/core/resources/app_text_styles.dart';

class NewNoteAppBar extends StatelessWidget implements PreferredSizeWidget {
  const NewNoteAppBar({super.key, this.title, this.leadingText});
  final String? title;
  final String? leadingText;

  @override
  Widget build(BuildContext context) {
    return AppBar(
      backgroundColor: AppColors.primary,
      elevation: 0,
      centerTitle: true,
      title: Text(
        title ?? 'Add Note',
        style: AppTextStyles.black16Medium,
      ),
      leadingWidth: 100,
      leading: Padding(
        padding: const EdgeInsets.symmetric(horizontal: AppSize.smPadding),
        child: GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              const Icon(Icons.arrow_back_ios,
                  color: AppColors.purple, size: 16),
              const SizedBox(width: AppSize.xsmSpacing),
              Text(
                leadingText ?? 'Back',
                style: AppTextStyles.black16Medium.copyWith(
                  color: AppColors.purple,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);
}
