import 'package:flutter/material.dart';
import 'package:new_capital_summer_db/core/resources/app_size.dart';
import 'package:new_capital_summer_db/core/resources/app_text_styles.dart';

import '../../core/resources/app_colors.dart';
import '../../model/note.dart';
import '../../db/crud.dart';

class NoteItemWidget extends StatelessWidget {
  const NoteItemWidget({super.key, required this.note});

  final Note note;

  void _showEditDialog(BuildContext context) {
    TextEditingController titleController =
        TextEditingController(text: note.title);
    TextEditingController contentController =
        TextEditingController(text: note.content);

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Edit Note'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: titleController,
              decoration: const InputDecoration(labelText: 'Title'),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: contentController,
              decoration: const InputDecoration(labelText: 'Content'),
              maxLines: 3,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Note updatedNote = note.copyWith(
                title: titleController.text,
                content: contentController.text,
              );
              Crud.instance.updateNote(updatedNote);
              Navigator.pop(context);
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 160,
      padding: const EdgeInsets.all(AppSize.smPadding),
      decoration: BoxDecoration(
        color: AppColors.lightYellow,
        borderRadius: AppSize.smRadius,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Text(
                  note.title,
                  style: AppTextStyles.black10Regular,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              GestureDetector(
                onTap: () => _showEditDialog(context),
                child: const Icon(Icons.edit, size: 18, color: Colors.blue),
              ),
              const SizedBox(width: 8),
              GestureDetector(
                onTap: () {
                  if (note.id != null) {
                    Crud.instance.deleteNote(note.id!);
                  }
                },
                child: const Icon(Icons.delete, size: 18, color: Colors.red),
              ),
            ],
          ),
          const SizedBox(height: AppSize.h16),
          Expanded(
            child: Text(
              note.content,
              style: AppTextStyles.black16Medium,
              overflow: TextOverflow.ellipsis,
              maxLines: 5,
            ),
          ),
        ],
      ),
    );
  }
}
