import 'package:flutter/material.dart';
import 'package:new_capital_summer_db/core/resources/app_icons.dart';
import 'package:new_capital_summer_db/core/resources/app_size.dart';
import 'package:new_capital_summer_db/extensions/context_extension.dart';
import 'package:new_capital_summer_db/extensions/grid_item_type_mapper.dart';
import 'package:new_capital_summer_db/presentation/screens/add_note_screen.dart';
import 'package:new_capital_summer_db/presentation/ui_model/grid_item.dart';
import 'package:flutter_svg/flutter_svg.dart';

class NoteTypeWidget extends StatelessWidget {
  const NoteTypeWidget({super.key, required this.item});

  final GridItem item;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => context.navigateTo(AddNoteScreen(noteType: item.toType())),
      child: Container(
        decoration: BoxDecoration(
          color: item.color,
          borderRadius: AppSize.smRadius,
        ),
        child: Padding(
          padding: EdgeInsets.all(AppSize.smPadding),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Stack(
                  children: [
                    SvgPicture.asset(AppIcons.background),
                    SvgPicture.asset(AppIcons.icon1),
                  ],
                ),
                Text(item.title),
                SizedBox(height: AppSize.h16),
                Text(item.description),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
