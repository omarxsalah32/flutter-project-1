import 'package:flutter/material.dart';
import 'package:new_capital_summer_db/model/note.dart';
import 'package:new_capital_summer_db/presentation/widgets/note_item_widget.dart';
import 'package:new_capital_summer_db/presentation/widgets/note_section_header.dart';
import '../../core/resources/app_size.dart';

class NoteSection extends StatelessWidget {
  const NoteSection({
    super.key,
    required this.sectionTitle,
    required this.onTap,
    required this.notes,
  });

  final String sectionTitle;
  final VoidCallback onTap;
  final List<Note> notes;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        NoteSectionHeader(onTap: onTap, sectionTitle: sectionTitle),
        const SizedBox(height: AppSize.h16),
        SizedBox(
          height: AppSize.h224,
          child: notes.isEmpty
              ? const Text('No notes here yet.',
                  style: TextStyle(color: Colors.grey))
              : ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemBuilder: (context, index) =>
                      NoteItemWidget(note: notes[index]),
                  separatorBuilder: (context, index) =>
                      const SizedBox(width: AppSize.mdSpacing),
                  itemCount: notes.length,
                ),
        ),
      ],
    );
  }
}
