import 'package:flutter/material.dart';
import 'package:new_capital_summer_db/core/resources/app_text_styles.dart';

class NoteSectionHeader extends StatelessWidget {
  const NoteSectionHeader({
    super.key,
    required this.onTap,
    required this.sectionTitle,
  });

  final VoidCallback onTap;
  final String sectionTitle;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(sectionTitle, style: AppTextStyles.black14Bold),
        GestureDetector(
          onTap: onTap,
          child: Text('View All', style: AppTextStyles.purple12MediumUnderline),
        ),
      ],
    );
  }
}
