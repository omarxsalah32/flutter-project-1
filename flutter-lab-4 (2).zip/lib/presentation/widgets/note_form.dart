import 'package:flutter/material.dart';
import 'package:new_capital_summer_db/core/resources/app_size.dart';
import 'package:new_capital_summer_db/presentation/widgets/app_text_field.dart';

class NoteForm extends StatelessWidget {
  const NoteForm({
    super.key,
    required this.formKey,
    required this.titleController,
    required this.contentController,
  });
  final GlobalKey<FormState> formKey;
  final TextEditingController titleController;
  final TextEditingController contentController;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: AppSize.mdPadding),
      child: Form(
        key: formKey,
        child: Column(
          children: [
            AppTextField(
              controller: titleController,
              isTitle: true,
              title: 'Title Here',
            ),
            Expanded(
              child: AppTextField(
                controller: contentController,
                title: 'Write your notes here...',
              ),
            ),
          ],
        ),
      ),
    );
  }
}
