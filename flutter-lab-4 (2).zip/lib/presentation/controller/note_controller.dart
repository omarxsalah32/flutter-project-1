import 'package:flutter/material.dart';
import 'package:new_capital_summer_db/extensions/context_extension.dart';
import 'package:new_capital_summer_db/enums/snackbar_type.dart';

import '../../db/crud.dart';
import '../../model/note.dart';

class NoteController {
  static Future<void> insertNewNote(Note note, BuildContext context) async {
    try {
      print("ATTEMPTING TO SAVE NOTE: ${note.toMap()}");

      int row = await Crud.instance.addNote(note);

      print("DATABASE RETURNED ROW ID: $row");

      if (!context.mounted) return;

      if (row != 0) {
        context.showSnackBar(
          'Note added successfully',
          type: SnackBarType.success,
        );

        Crud.instance.viewAllNotes();

        Navigator.pop(context);
      } else {
        context.showSnackBar(
          'Failed to add note: Database returned 0',
          type: SnackBarType.error,
        );
      }
    } catch (e) {
      print("DATABASE ERROR: $e");
    }
  }
}
