import 'package:flutter/material.dart';
import 'package:new_capital_summer_db/core/resources/app_size.dart';
import 'package:new_capital_summer_db/presentation/widgets/note_section.dart';
import 'package:new_capital_summer_db/db/crud.dart';
import 'package:new_capital_summer_db/model/note.dart';
import 'package:new_capital_summer_db/enums/note_type.dart';

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  void initState() {
    super.initState();
    Crud.instance.viewAllNotes();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: ValueListenableBuilder<List<Note>>(
          valueListenable: Crud.notesNotifier,
          builder: (context, notes, child) {
            // Filter notes accurately by your enum types
            final interestingIdeas =
                notes.where((n) => n.type == NoteType.interesting).toList();
            final goals = notes.where((n) => n.type == NoteType.goals).toList();
            final guidance =
                notes.where((n) => n.type == NoteType.guidance).toList();
            final buySomething =
                notes.where((n) => n.type == NoteType.buy).toList();
            final routineTasks =
                notes.where((n) => n.type == NoteType.routines).toList();

            return SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.all(AppSize.mdPadding),
                child: Column(
                  children: [
                    NoteSection(
                      sectionTitle: 'Interesting Idea',
                      onTap: () {},
                      notes: interestingIdeas,
                    ),
                    NoteSection(
                      sectionTitle: 'Goals',
                      onTap: () {},
                      notes: goals,
                    ),
                    NoteSection(
                      sectionTitle: 'Guidance',
                      onTap: () {},
                      notes: guidance,
                    ),
                    NoteSection(
                      sectionTitle: 'Buy Something',
                      onTap: () {},
                      notes: buySomething,
                    ),
                    NoteSection(
                      sectionTitle: 'Routine Tasks',
                      onTap: () {},
                      notes: routineTasks,
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
