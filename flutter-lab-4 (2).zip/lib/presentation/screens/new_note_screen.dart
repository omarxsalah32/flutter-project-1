import 'package:flutter/material.dart';
import 'package:new_capital_summer_db/core/constants/ui_constants.dart';
import 'package:new_capital_summer_db/core/resources/app_colors.dart';
import 'package:new_capital_summer_db/core/resources/app_size.dart';
import 'package:new_capital_summer_db/core/resources/app_text_styles.dart';
import 'package:new_capital_summer_db/presentation/widgets/new_note_app_bar.dart';
import 'package:new_capital_summer_db/presentation/widgets/note_type_widget.dart';

class NewNoteScreen extends StatelessWidget {
  const NewNoteScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.primary,
      appBar: const NewNoteAppBar(leadingText: 'Home', title: 'New Notes'),
      body: Padding(
        padding: const EdgeInsets.all(AppSize.mdPadding),
        child: Column(
          children: [
            const Text(
              'What Do You Want to Notes?',
              style: AppTextStyles.black24Bold,
            ),
            const SizedBox(height: AppSize.h32),
            Expanded(
              child: GridView.builder(
                itemCount: UiConstants.gridItems.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: AppSize.w16,
                  mainAxisSpacing: AppSize.h16,
                ),
                itemBuilder: (context, index) =>
                    NoteTypeWidget(item: UiConstants.gridItems[index]),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
