import 'package:flutter/material.dart';
import 'package:new_capital_summer_db/core/resources/app_colors.dart';
import 'package:new_capital_summer_db/enums/note_type.dart';
import 'package:new_capital_summer_db/model/note.dart';
import 'package:new_capital_summer_db/presentation/controller/note_controller.dart';
import 'package:new_capital_summer_db/presentation/widgets/add_note_bottom_bar.dart';
import 'package:new_capital_summer_db/presentation/widgets/new_note_app_bar.dart';
import 'package:new_capital_summer_db/presentation/widgets/note_form.dart';
import 'package:new_capital_summer_db/utils/data_time_manager.dart';

class AddNoteScreen extends StatefulWidget {
  const AddNoteScreen({super.key, required this.noteType});

  final NoteType noteType;

  @override
  State<AddNoteScreen> createState() => _AddNoteScreenState();
}

class _AddNoteScreenState extends State<AddNoteScreen> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _contentController = TextEditingController();

  @override
  void dispose() {
    _titleController.dispose();
    _contentController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.primary,
      appBar: NewNoteAppBar(),
      body: NoteForm(
        formKey: _formKey,
        titleController: _titleController,
        contentController: _contentController,
      ),
      bottomNavigationBar: AddNoteBottomBar(
        onTap: () {
          if (_formKey.currentState!.validate()) {
            Note note = Note(
              type: widget.noteType,
              title: _titleController.text,
              content: _contentController.text,
              createdAt: DateTimeManager.getCurrentDateTime(),
            );
            NoteController.insertNewNote(note, context);
          }
        },
      ),
    );
  }
}
