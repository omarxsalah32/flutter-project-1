import 'package:flutter/material.dart';
import 'package:new_capital_summer_db/core/constants/ui_constants.dart';
import 'package:new_capital_summer_db/core/resources/app_colors.dart';
import 'package:new_capital_summer_db/extensions/context_extension.dart';

import 'new_note_screen.dart';

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _pageIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: UiConstants.navItems[_pageIndex].page,
      floatingActionButton: FloatingActionButton(
        backgroundColor: AppColors.purple,
        shape: CircleBorder(),
        onPressed: () => context.navigateTo(NewNoteScreen()),
        child: Icon(Icons.add, color: AppColors.primary),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        backgroundColor: AppColors.primary,
        currentIndex: _pageIndex,
        onTap: (value) {
          setState(() {
            _pageIndex = value;
          });
        },
        items: UiConstants.navItems
            .map(
              (e) =>
                  BottomNavigationBarItem(icon: Icon(e.icon), label: e.label),
            )
            .toList(),
      ),
    );
  }
}
