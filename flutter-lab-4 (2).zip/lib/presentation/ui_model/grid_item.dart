import 'package:flutter/material.dart';

class GridItem {
  final String icon;
  final String title;
  final String description;
  final Color color;

  const GridItem(this.icon, this.title, this.description, this.color);
}
