package com.example.new_capital_summer_db

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
