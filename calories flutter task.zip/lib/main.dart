import 'package:flutter/material.dart';

void main() => runApp(NutritionApp());

class NutritionApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: NutritionTable(),
    );
  }
}

class NutritionItem {
  String name;
  int calories;
  bool isSelected;

  NutritionItem(
      {required this.name, required this.calories, this.isSelected = false});
}

class NutritionTable extends StatefulWidget {
  @override
  _NutritionTableState createState() => _NutritionTableState();
}

class _NutritionTableState extends State<NutritionTable> {
  // Data provided from the assignment image
  List<NutritionItem> items = [
    NutritionItem(name: 'Frozen yogurt', calories: 159), //[cite: 1]
    NutritionItem(name: 'Ice cream sandwich', calories: 237), //[cite: 1]
    NutritionItem(name: 'Eclair', calories: 262), //[cite: 1]
    NutritionItem(name: 'Cupcake', calories: 305), //[cite: 1]
    NutritionItem(name: 'Gingerbread', calories: 356), //[cite: 1]
    NutritionItem(name: 'Jelly bean', calories: 375), //[cite: 1]
    NutritionItem(name: 'Lollipop', calories: 392), //[cite: 1]
    NutritionItem(name: 'Honeycomb', calories: 408), //[cite: 1]
    NutritionItem(name: 'Donut', calories: 452), //[cite: 1]
  ];

  int get totalCalories {
    return items
        .where((item) => item.isSelected)
        .fold(0, (sum, item) => sum + item.calories);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Data tables'),
        backgroundColor: Colors.blue,
      ),
      body: ListView(
        children: [
          DataTable(
            columns: [
              DataColumn(
                  label: Text('Dessert (100g serving)',
                      style:
                          TextStyle(fontWeight: FontWeight.bold))), //[cite: 1]
              DataColumn(
                  label: Text('Calories',
                      style:
                          TextStyle(fontWeight: FontWeight.bold))), //[cite: 1]
            ],
            rows: items.map((item) {
              return DataRow(
                selected: item.isSelected,
                onSelectChanged: (bool? selected) {
                  setState(() {
                    item.isSelected = selected ?? false;
                  });
                },
                cells: [
                  DataCell(Text(item.name)),
                  DataCell(Text(item.calories.toString())),
                ],
              );
            }).toList(),
          ),
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: Text(
              'Total Calories: $totalCalories',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
          )
        ],
      ),
    );
  }
}
