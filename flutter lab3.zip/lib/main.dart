import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Lab 3',
      theme: ThemeData(
        primarySwatch: Colors.deepPurple,
      ),
      home: const MainScreen(),
    );
  }
}

class MainScreen extends StatelessWidget {
  const MainScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Stocks App - Lab 3'),
        backgroundColor: Colors.deepPurple,
        foregroundColor: Colors.white,
      ),
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            showModalBottomSheet(
              context: context,
              isScrollControlled: true,
              backgroundColor: Colors.transparent,
              builder: (context) => const FilterBottomSheet(),
            );
          },
          child: const Text('Open Filters'),
        ),
      ),
    );
  }
}

class FilterBottomSheet extends StatefulWidget {
  const FilterBottomSheet({super.key});

  @override
  State<FilterBottomSheet> createState() => _FilterBottomSheetState();
}

class _FilterBottomSheetState extends State<FilterBottomSheet> {
  int _percentage = 5;
  String _arrowDirection = '↑';
  String _selectedTimePeriod = 'Year';

  final List<String> _timePeriods = ['Wk', '30D', '90D', 'Year'];

  @override
  void initState() {
    super.initState();
    _loadSavedData();
  }

  Future<void> _loadSavedData() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _percentage = prefs.getInt('saved_percentage') ?? 5;
      _arrowDirection = prefs.getString('saved_arrow') ?? '↑';
      _selectedTimePeriod = prefs.getString('saved_time_period') ?? 'Year';
    });
  }

  // Apply Button: Save data to our Mock Shared Preferences
  Future<void> _applyAndSave() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('saved_percentage', _percentage);
    await prefs.setString('saved_arrow', _arrowDirection);
    await prefs.setString('saved_time_period', _selectedTimePeriod);

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Preferences Saved Successfully!')),
      );
      Navigator.pop(context); // Close the bottom sheet
    }
  }

  // Reset Button logic
  void _resetToOriginal() {
    setState(() {
      _percentage = 5;
      _arrowDirection = '↑';
      _selectedTimePeriod = 'Year';
    });
  }

  void _incrementPercentage() {
    setState(() {
      _percentage += 5;
      _arrowDirection = '↑';
    });
  }

  void _decrementPercentage() {
    if (_percentage > 5) {
      setState(() {
        _percentage -= 5;
        _arrowDirection = '↓';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24.0)),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16.0),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: Colors.grey[400],
              borderRadius: BorderRadius.circular(10),
            ),
          ),
          const SizedBox(height: 24),
          const Text(
            'Stock Performance',
            style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  shape: BoxShape.circle,
                ),
                child: IconButton(
                  icon: const Icon(Icons.remove, color: Colors.black),
                  onPressed: _decrementPercentage,
                ),
              ),
              const SizedBox(width: 16),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey[300]!),
                  borderRadius: BorderRadius.circular(24),
                ),
                child: Text(
                  '$_arrowDirection $_percentage% or Higher',
                  style: const TextStyle(fontWeight: FontWeight.w500),
                ),
              ),
              const SizedBox(width: 16),
              Container(
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  shape: BoxShape.circle,
                ),
                child: IconButton(
                  icon: const Icon(Icons.add, color: Colors.black),
                  onPressed: _incrementPercentage,
                ),
              ),
            ],
          ),
          const SizedBox(height: 32),
          const Text(
            'Time Period',
            style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: _timePeriods.map((period) {
              final isSelected = _selectedTimePeriod == period;
              return GestureDetector(
                onTap: () {
                  setState(() {
                    _selectedTimePeriod = period;
                  });
                },
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                  decoration: BoxDecoration(
                    color: isSelected ? Colors.white : Colors.grey[100],
                    border: isSelected
                        ? Border.all(color: Colors.deepPurple, width: 1.5)
                        : Border.all(color: Colors.transparent),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    period,
                    style: TextStyle(
                      color: isSelected ? Colors.deepPurple : Colors.black87,
                      fontWeight:
                          isSelected ? FontWeight.bold : FontWeight.normal,
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 32),
          TextButton(
            onPressed: _resetToOriginal,
            child: const Text(
              'Reset',
              style: TextStyle(
                color: Colors.deepPurple,
                fontWeight: FontWeight.w600,
                fontSize: 16,
              ),
            ),
          ),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            height: 50,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.deepPurple,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(25),
                ),
                elevation: 0,
              ),
              onPressed: _applyAndSave,
              child: const Text(
                'Apply',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
            ),
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }
}

class SharedPreferences {
  static final SharedPreferences _instance = SharedPreferences._internal();
  factory SharedPreferences() => _instance;
  SharedPreferences._internal();

  final Map<String, dynamic> _storage = {};

  static Future<SharedPreferences> getInstance() async {
    return _instance;
  }

  int? getInt(String key) => _storage[key] as int?;
  String? getString(String key) => _storage[key] as String?;

  Future<bool> setInt(String key, int value) async {
    _storage[key] = value;
    return true;
  }

  Future<bool> setString(String key, String value) async {
    _storage[key] = value;
    return true;
  }
}
