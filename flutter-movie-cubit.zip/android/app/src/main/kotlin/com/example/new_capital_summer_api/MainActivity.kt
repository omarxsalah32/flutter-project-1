package com.example.new_capital_summer_api

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
