import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'model/response/movie.dart';
import 'eticket_screen.dart';

class DetailsScreen extends StatelessWidget {
  final Movie movie;

  const DetailsScreen({super.key, required this.movie});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('Details Movie',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
              icon: const Icon(Icons.bookmark_outline, color: Colors.white),
              onPressed: () {}),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Poster Carousel display
            SizedBox(
              height: 320,
              child: Center(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: CachedNetworkImage(
                    imageUrl: movie.posterUrl,
                    fit: BoxFit.cover,
                    width: 220,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),

            // Title
            Text(movie.title,
                style:
                    const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),

            // Director & Rating
            Row(
              children: [
                const Text('Director: Destin Daniel Cretton  |',
                    style: TextStyle(color: Colors.grey, fontSize: 13)),
                const SizedBox(width: 6),
                const Icon(Icons.star, color: Colors.amber, size: 16),
                const SizedBox(width: 4),
                Text(movie.voteAverage.toStringAsFixed(1),
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 13,
                        fontWeight: FontWeight.bold)),
              ],
            ),
            const SizedBox(height: 16),

            // Category Chips
            Row(
              children: [
                _buildTag('Action'),
                const SizedBox(width: 8),
                _buildTag('Fiction Fantasy'),
                const SizedBox(width: 8),
                _buildTag('02h 43m'),
              ],
            ),
            const SizedBox(height: 24),

            // Synopsis
            const Text('Synopsis',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text(
              movie.overview,
              style:
                  TextStyle(color: Colors.grey[400], fontSize: 13, height: 1.5),
            ),
            const SizedBox(height: 32),

            // Book Ticket Button
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => ETicketScreen(movie: movie)));
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF5998D6),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)),
                ),
                child: const Text('Book Ticket',
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.white)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTag(String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: const Color(0xFF232533),
        borderRadius: BorderRadius.circular(20),
      ),
      child:
          Text(text, style: const TextStyle(color: Colors.grey, fontSize: 12)),
    );
  }
}
