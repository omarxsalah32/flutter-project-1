import 'package:flutter_bloc/flutter_bloc.dart';
import '../api/movie_api_service.dart';
import 'movie_state.dart';

class MovieCubit extends Cubit<MovieState> {
  final MovieApiService apiService;

  // Start the app in the "Initial" state
  MovieCubit(this.apiService) : super(MovieInitial());

  Future<void> fetchMovies() async {
    emit(MovieLoading()); // Tell the UI to show a loading spinner

    try {
      final movies = await apiService.fetchNowPlaying();
      emit(MovieLoaded(movies)); // Tell the UI to show the movie posters
    } catch (e) {
      emit(MovieError(e.toString())); // Tell the UI to show an error
    }
  }
}
