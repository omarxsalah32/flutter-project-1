class ApiConstants {
  static const String baseUrl = 'https://api.themoviedb.org/3';
  static const String apiKey = '4cac8eacaaa8e95ca0c0286eb6d1e466';
  static const String nowPlayingEndpoint = '/movie/now_playing';
}
