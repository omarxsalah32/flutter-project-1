import 'package:dio/dio.dart';
import '../model/response/movie.dart';
import 'api_constants.dart';

class MovieApiService {
  final Dio _dio = Dio();

  Future<List<Movie>> fetchNowPlaying() async {
    try {
      final response = await _dio.get(
        '${ApiConstants.baseUrl}${ApiConstants.nowPlayingEndpoint}',
        queryParameters: {
          'api_key': ApiConstants.apiKey,
        },
      );

      if (response.statusCode == 200) {
        final List results = response.data['results'];
        return results.map((json) => Movie.fromJson(json)).toList();
      } else {
        throw Exception('Failed to load movies');
      }
    } catch (e) {
      throw Exception('Network error: $e');
    }
  }
}
