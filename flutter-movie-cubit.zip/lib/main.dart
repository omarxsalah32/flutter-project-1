import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'main_screen.dart';
import 'api/movie_api_service.dart';
import 'cubit/movie_cubit.dart';

void main() {
  runApp(const MovieTicketApp());
}

class MovieTicketApp extends StatelessWidget {
  const MovieTicketApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider<MovieCubit>(
          // Create the Cubit and trigger the API call immediately
          create: (context) => MovieCubit(MovieApiService())..fetchMovies(),
        ),
      ],
      child: MaterialApp(
        title: 'Movie Ticket App',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          brightness: Brightness.dark,
          scaffoldBackgroundColor: const Color(0xFF151724),
          primaryColor: const Color(0xFF5998D6),
          cardColor: const Color(0xFF232533),
          appBarTheme: const AppBarTheme(
            backgroundColor: Colors.transparent,
            elevation: 0,
            centerTitle: true,
          ),
        ),
        home: const MainScreen(),
      ),
    );
  }
}
