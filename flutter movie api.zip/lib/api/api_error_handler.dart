import 'package:dio/dio.dart';

class ApiErrorHandler {
  static String getMessage(DioException exception) {
    switch (exception.type) {
      case .receiveTimeout:
      case .connectionTimeout:
      case .sendTimeout:
        return 'TimeOut, check your connection';
      case .connectionError:
        return 'No Internet Connection';
      case .badResponse:
        return _handleBadRequest(exception.response);
      default:
        return 'Something went wrong';
    }
  }

  static String _handleBadRequest(Response<dynamic>? response) {
    switch (response?.statusCode) {
      case 400:
        return '';
      case 401:
        return 'Invalid user credential';
      case 404:
        return 'Invalid endpoint';
      default:
        return '${response?.statusMessage ?? response?.data ?? 'Sn error occurred'}';
    }
  }
}
