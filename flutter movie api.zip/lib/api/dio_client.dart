import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:new_capital_summer_api/api/api_constants.dart';

class DioClient {
  DioClient._();

  static Dio getClient() {
    Dio dio = Dio()
      ..options.baseUrl = ApiConstants.baseUrl
      ..options.method = 'GET'
      ..options.receiveTimeout = ApiConstants.timeOut
      ..options.connectTimeout = ApiConstants.timeOut
      ..options.queryParameters = {"lang": "ar"}
      ..options.contentType = ContentType.json.toString()
      ..options.headers = {"accept": "application/json"}
      ..interceptors.addAll([AppInterceptor(), AuthInterceptor()]);
    return dio;
  }
}

class AuthInterceptor extends InterceptorsWrapper {
  @override
  void onRequest(RequestOptions options, RequestInterceptorHandler handler) {
    options.headers["authorization"] = "Bearer xxx";
    debugPrint(options.headers['authorization']);
    handler.next(options);
  }
}

class AppInterceptor extends InterceptorsWrapper {
  @override
  void onRequest(RequestOptions options, RequestInterceptorHandler handler) {
    debugPrint('''*****=====Request====***
url : ${options.uri.path}
end point : ${options.path}
params : ${options.queryParameters['lang']}
--------------------------------------------''');
    handler.next(options);
  }

  @override
  void onError(DioException err, ErrorInterceptorHandler handler) {
    debugPrint('''
type ${err.type}
text: ${err.message}
----------------------------''');
    handler.next(err);
  }
}
