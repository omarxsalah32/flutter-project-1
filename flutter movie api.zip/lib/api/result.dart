import 'package:new_capital_summer_api/api/api_exception.dart';

sealed class Result<T> {}

class Success<T> extends Result<T> {
  final T? data;

  Success(this.data);
}

class Failure<T> extends Result<T> {
  final ApiException exception;

  Failure(this.exception);
}
