import 'package:flutter/material.dart';
import 'dart:math';

void main() => runApp(DiceApp());

class DiceApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: DicePage(),
    );
  }
}

class DicePage extends StatefulWidget {
  @override
  _DicePageState createState() => _DicePageState();
}

class _DicePageState extends State<DicePage> {
  int leftDiceNumber = 6;
  int rightDiceNumber = 6;

  void rollDice() {
    setState(() {
      leftDiceNumber = Random().nextInt(6) + 1;
      rightDiceNumber = Random().nextInt(6) + 1;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.green[800],
      appBar: AppBar(
        title: Text(
          'Hello Dice',
          style: TextStyle(color: Colors.white),
        ),
        centerTitle: true,
        backgroundColor: Colors.green[900],
      ),
      // Removed the Center widget here to allow vertical spacing
      body: Column(
        children: [
          SizedBox(
              height: 120), // Pushes the dice down just a bit from the top bar
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 100,
                height: 100,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(15), // Rounds the corners
                ),
                child: Center(
                  child: Text(
                    '$leftDiceNumber',
                    style: TextStyle(fontSize: 40, color: Colors.red),
                  ),
                ),
              ),
              SizedBox(width: 20),
              Container(
                width: 100,
                height: 100,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(15), // Rounds the corners
                ),
                child: Center(
                  child: Text(
                    '$rightDiceNumber',
                    style: TextStyle(fontSize: 40, color: Colors.red),
                  ),
                ),
              ),
            ],
          ),
          SizedBox(
              height: 200), // Creates a large gap, pushing the Roll button down
          TextButton.icon(
            onPressed: rollDice,
            icon: Icon(Icons.casino),
            label: Text(
              'Roll',
              style: TextStyle(fontSize: 20),
            ),
            style: TextButton.styleFrom(
              foregroundColor:
                  Colors.white, // Colors both the icon and the text white
            ),
          ),
        ],
      ),
    );
  }
}
